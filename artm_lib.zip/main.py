def main():
    print("Hello from py-artm!")


if __name__ == "__main__":
    main()
